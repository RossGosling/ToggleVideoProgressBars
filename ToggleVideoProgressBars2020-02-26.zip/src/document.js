(async() => {
    try {

        //////////////////////////////////////////////////////

        // Define Methods

        const setHidden = (isHidden) => {

            // IF valid page
            if (window.location.pathname.includes(config[siteName].pathPattern)) {

                const display = (isHidden) ? 'none' : '';
                
                const classNames = config[siteName].classNames;

                for(let i = 0; i < classNames.length; i++) {
                    const className = classNames[i];

                    const element = document.getElementsByClassName(className)[0];

                    if (element) {
                        element.style.display = display;

                    } else {
                        console.warn('ClassName not found', className);
                    }
                }
            }
        }

        //////////////////////////////////////////////////////

        const siteName = window.location.hostname.split('.').reduce((result, string) => {

            if (typeof result !== 'undefined') {
                return  result;
            }

            return Object.keys(config).find(
                (supportedSiteName) => string
                    .toLowerCase()
                    .includes(
                        supportedSiteName.toLowerCase()
                    )
            );

        }, undefined);


        console.log(`Instantiated ${siteName} document!`)

        // Register Listener for Document Load
    
        // TODO - This doesn't work, kill me
    
        const onLoad = async() => setHidden(await setting.isHidden());
    
        onLoad();
    
        window.onload = () => {
            console.log('window.onload = () => {');
            onLoad();
        };
    
        window.addEventListener('load', (event) => {
            console.log('window.addEventListener(\'load\', (event) => {');
            onLoad();
        });
        
        document.addEventListener('readystatechange', (event) => {
            console.log('document.addEventListener(\'readystatechange\', (event) => {');
            onLoad();
        });
        
        document.addEventListener('DOMContentLoaded', (event) => {
            console.log('document.addEventListener(\'DOMContentLoaded\', (event) => {');
            onLoad();
        });
    

        //////////////////////////////////////////////////////

        if (typeof siteName !== 'undefined') {

            // Register Listener for KeyPress

            document.addEventListener(
                'keypress',
                (keyPressEvent) => {
                    try {
                        
                        if (
                            window.location.pathname.includes(config[siteName].pathPattern) &&
                            (keyPressEvent === null || keyPressEvent.key === 's')
                        ) {

                            return browser.runtime.sendMessage(
                                {
                                    type: MESSAGE_TOGGLE
                                }
                            );
                        }

                    } catch (error) {
                        console.error(error);
                    }
                },
                false
            );

            // Register Listener for Background Messages

            browser.runtime.onMessage.addListener(
                (message) => {
                    try {
        
                        if (message.type == MESSAGE_SET) {
        
                            return setHidden(message.isHidden);
                        }
        
                    } catch (error) {
                        console.error(error);
                    }
                }
            );
        }

        //////////////////////////////////////////////////////

    } catch (error) {
        console.error(error);
    }
})();