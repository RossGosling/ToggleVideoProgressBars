
//////////////////////////////////////////////////////

// Configuration

const config = {

    Netflix: {
        pathPattern: '/watch',
        classNames: [
            'scrubber-container',
            'time-remaining__time'
        ]
    },

    YouTube: {
        pathPattern: '',
        classNames: [
            'ytp-time-display',
            'ytp-chapters-container',
            'ytp-progress-bar-container',
            'ytp-scrubber-container'
        ]
    },

    Amazon: {
        pathPattern: '/video/detail/',
        classNames: [
            'time',
            'seekBar'
        ]
    },

    Vimeo: {
        pathPattern: '/',
        classNames: [
            'vp-progress'
        ]
    }
};

//////////////////////////////////////////////////////

// Constants

const CONTEXTMENU_ID = 'context.menu'

const MESSAGE_TOGGLE = 'toggle'
const MESSAGE_SET = 'set'

//////////////////////////////////////////////////////

const setting = {

    isHidden: async() => {

        const setting = await browser.storage.local.get('isHidden');
    
        return ('isHidden' in setting) ?
            setting.isHidden :
            false;
    },
    
    setHidden: async(isHidden) => browser.storage.local.set({ isHidden }),
}

//////////////////////////////////////////////////////

// Logging override

window.console = (() => {
    
    const prefix = ['ToggleVideoProgressBars:'];

    const originalConsole = window.console;

    const getNow = () => new Date()
        .toISOString()
        .substring(11, 19);

    return {
        log: (...args) => originalConsole.log(`[LOG: ${getNow()}]`, prefix.join(' '), ...args),
        info: (...args) => originalConsole.info(`[INFO: ${getNow()}]`, prefix.join(' '), ...args),
        warn: (...args) => originalConsole.warn(`[WARN: ${getNow()}]`, prefix.join(' '), ...args),
        error: (...args) => originalConsole.error(`[ERROR: ${getNow()}]`, prefix.join(' '), ...args),
    };

})();

//////////////////////////////////////////////////////

// Chrome supporting standard browser object, no bespoke bs here

if (typeof browser === 'undefined') {

    browser =  chrome;
}

//////////////////////////////////////////////////////
