(async() => {
    try {
        
        //////////////////////////////////////////////////////

        // Define Methods

        const setIcon = (isHidden) => {
        
            browser.browserAction.setIcon({
                path: (isHidden) ? "./icon/hidden.png" : "./icon/visible.png",
            });
        }

        const toggleHidden = async(senderTab = null) => {
            try {

                const isHidden = !(await setting.isHidden());

                console.info('Set isHidden to', (isHidden) ? 'hidden' : 'visible');

                await setting.setHidden(isHidden)

                setIcon(isHidden);

                browser.tabs.query(
                    { active: true }, // TODO - should be all, not just active
                    (tabs) => tabs.map(
                        (tab) => browser.tabs.sendMessage(
                            tab.id,
                            {
                                type: MESSAGE_SET,
                                isHidden,
                            }
                        )
                    )
                );
                
                return isHidden;

            } catch (error) {
                console.error(error);
            }
        }

        //////////////////////////////////////////////////////

        // Run on startup

        const isHidden = await setting.isHidden();
        setIcon(isHidden);
        console.log(`Instantiated background - Hidden: ${isHidden}!`)

        //////////////////////////////////////////////////////

        // Register Button

        browser.browserAction.onClicked.addListener(
            () => {
                try {

                    return toggleHidden();

                } catch (error) {
                    console.error(error);
                }
            }
        );

        // Register Context Menu Option

        const contextMenuTitlePrefix = 'Toggle Progress Bars to ';
        const contextMenuTitleSuffix = '';

        browser.contextMenus.create(
            {
                id: CONTEXTMENU_ID,
                title:  `${contextMenuTitlePrefix}${(!isHidden) ? 'hidden' : 'visible'}${contextMenuTitleSuffix}`,
               
                onclick: async() => {
                    try {

                        const newHidden = await toggleHidden();

                        browser.contextMenus.update(
                            CONTEXTMENU_ID,
                            {
                                title:  `${contextMenuTitlePrefix}${(!newHidden) ? 'hidden' : 'visible'}${contextMenuTitleSuffix}`,
                            }
                        );

                    } catch (error) {
                        console.error(error);
                    }
                }
            }
        );

        // Register Listener for Document Messages

        browser.runtime.onMessage.addListener(
            (message, sender) => {
                try {

                    if (message.type == MESSAGE_TOGGLE) {

                        return toggleHidden(sender.tab);
                    }

                } catch (error) {
                    console.error(error);
                }
            }
        );

        //////////////////////////////////////////////////////

    } catch (error) {
        console.error(error);
    }
})();